export const REM_UNIT = 120
export const DESIGN_WIDTH = 1200 // 设计稿的宽
export const DESIGN_HEIGHT = 800 // 设计稿的高

export const DESIGN_WIDTH_SMALL = 500
export const DESIGN_HEIGHT_SMALL = 300

export const DESIGN_ARC_BALL = 80

export const BASE_WIN_WIDTH = 1920 // 标准分辨率宽
export const BASE_WIN_HEIGHT = 1200 // 标准分辨率高

export const VIDEO_PATH = 'd:/laowan'